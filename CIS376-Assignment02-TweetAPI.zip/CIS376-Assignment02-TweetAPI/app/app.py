from flask import Flask, jsonify
import json
import re

app = Flask(__name__)

# Load data once at startup
with open("favs.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# Route 1: Get all tweets (created_at, id, text)
@app.route('/tweets', methods=['GET'])
def get_all_tweets():
    return jsonify([
        {"created_at": t["created_at"], "id": t["id"], "text": t["text"]}
        for t in data
    ])

# Route 2: Get external links grouped by tweet ID
@app.route('/tweets/links', methods=['GET'])
def get_all_links():
    url_regex = r'https?://\S+'
    result = {}
    for t in data:
        links = re.findall(url_regex, t.get("text", ""))
        if links:
            result[t["id"]] = links
    return jsonify(result)

# Route 3: Get tweet details by ID
@app.route('/tweets/<int:tweet_id>', methods=['GET'])
def get_tweet_details(tweet_id):
    for t in data:
        if t["id"] == tweet_id:
            return jsonify({
                "created_at": t["created_at"],
                "text": t["text"],
                "screen_name": t["user"]["screen_name"]
            })
    return jsonify({"error": "Tweet not found"}), 404

# Route 4: Get user profile info by screen name
@app.route('/users/<screen_name>', methods=['GET'])
def get_user_profile(screen_name):
    for t in data:
        user = t.get("user", {})
        if user.get("screen_name", "").lower() == screen_name.lower():
            return jsonify({
                "location": user.get("location"),
                "description": user.get("description"),
                "followers_count": user.get("followers_count"),
                "friends_count": user.get("friends_count")
            })
    return jsonify({"error": "User not found"}), 404


if __name__ == '__main__':
    app.run(debug=True)


